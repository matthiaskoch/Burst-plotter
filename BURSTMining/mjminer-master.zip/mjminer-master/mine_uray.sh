#!/bin/sh
./mine_pool_all burst-pool.cryptoport.io:80 $@

