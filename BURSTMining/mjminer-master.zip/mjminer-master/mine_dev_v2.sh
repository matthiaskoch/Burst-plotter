#!/bin/sh
./mine_pool_share 178.62.39.204:8121 $@

