#!/bin/sh
./mine_pool_share 198.199.103.145:8121 $@

